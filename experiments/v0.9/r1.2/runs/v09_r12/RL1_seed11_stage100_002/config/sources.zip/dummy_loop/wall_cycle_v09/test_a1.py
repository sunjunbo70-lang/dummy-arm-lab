"""A1 contract and numerical tests; never connect hardware."""
import unittest,pickle,copy
import numpy as np
import torch
from .environment import Env
from .trajectory_action import decode
from .config import config
from .reward_quality import reward
from .learner import HybridPolicy

class A1Tests(unittest.TestCase):
 def test_geometry_continuous_and_bounded(self):
  rng=np.random.default_rng(1);c=config()
  for _ in range(20):
   d=decode(rng.uniform(-1,1,19),c,.05);p=np.array([d.at(t)[0] for t in np.linspace(0,1,200)])
   np.testing.assert_allclose(p[[0,-1]],d.points[[0,-1]])
   self.assertLess(abs(p[:,0]).max()+.062,.25);self.assertLess(abs(p[:,1]-.25).max()+.062,.25)
   self.assertLess(np.linalg.norm(np.diff(p,axis=0),axis=1).max(),.01)
 def test_no_truth_input_and_restore(self):
  e=Env(seed=60022);o=e.observe();e.material.wall[:]=.009;e.material.blade[:]=.02;e.material.carry_loss_m3=5
  np.testing.assert_array_equal(o,e.observe())
  e=Env(seed=60022);f=pickle.loads(pickle.dumps(e));a=e.teacher();x=e.step(a);y=f.step(a)
  np.testing.assert_array_equal(x[0],y[0]);self.assertEqual(x[1:3],y[1:3])
 def test_material_conservation(self):
  e=Env(seed=60025,task='edge_ridge');rng=np.random.default_rng(2)
  for k in range(20):
   a=(0,np.zeros(19)) if k==0 else (1,rng.uniform(-1,1,19));o,r,d,i=e.step(a)
   self.assertLess(abs(i['metrics']['volume_error_m3']),1e-10)
 def test_reward_order(self):
  z=[0,0,0]
  giveup=reward(.8,.8,z,1,terminal=True)
  repair=reward(.8,.2,z,10)+reward(.2,.2,z,1,terminal=True)
  self.assertGreater(repair,giveup)
  self.assertLess(reward(.2,.2,z,1),0)
  self.assertLess(reward(.2,.8,z,1)+reward(.8,.2,z,1),0)
  self.assertGreater(reward(.01,.01,z,1,terminal=True,success=True),reward(.01,.2,z,1,terminal=True))
 def test_cpu_gpu_forward_gradient_adam(self):
  if not torch.cuda.is_available():self.skipTest('CUDA required')
  torch.manual_seed(2);cpu=HybridPolicy(20);gpu=copy.deepcopy(cpu).cuda();x=torch.randn(16,20);valid=torch.ones(16,4,dtype=torch.bool);op=torch.arange(16)%4;raw=torch.randn(16,19)
  opts=[torch.optim.Adam(cpu.parameters(),lr=3e-5),torch.optim.Adam(gpu.parameters(),lr=3e-5)]
  outputs=[]
  for m,opt,device in [(cpu,opts[0],'cpu'),(gpu,opts[1],'cuda')]:
   lp,ent,v=m.evaluate(x.to(device),valid.to(device),op.to(device),raw.to(device));loss=-lp.mean()+v.square().mean();outputs.append((lp.detach().cpu(),v.detach().cpu()));loss.backward();opt.step()
  torch.testing.assert_close(outputs[0][0],outputs[1][0],atol=2e-5,rtol=2e-5)
  for a,b in zip(cpu.parameters(),gpu.parameters()):torch.testing.assert_close(a,b.cpu(),atol=2e-5,rtol=2e-5)
if __name__=='__main__':unittest.main()
