"""Shared deterministic evaluation; nominal and full execution are labelled separately."""
import json
from pathlib import Path
import numpy as np
from .environment import Env,TASKS
from .reach import Reach

def episode(model,seed,reach_path,backend='nominal',task=None,teacher=None,record=None,kwargs=None):
 e=Env(seed,Reach(reach_path),backend,task or TASKS[seed%6],**(kwargs or {}));initial=e.initial_wall.copy();initial_J=e.metrics()["J"];rows=[];frames=[];ret=0
 while not e.done:
  if model is None:action=e.teacher(strong=teacher=='T+',no_plateau=teacher=='T_budget')
  else:
   import torch
   device=next(model.parameters()).device
   with torch.no_grad(),torch.random.fork_rng(devices=[device.index or 0] if device.type=='cuda' else []):op,a,_,_,_=model.sample(torch.tensor(e.observe(),device=device).unsqueeze(0),torch.tensor(e.valid_ops(),device=device).unsqueeze(0),deterministic=True)
   action=(int(op.item()),a[0].cpu().numpy())
  _,r,_,info=e.step(action);ret+=r;rows.append({'op':action[0],'parameters':action[1].tolist(),'reward':r,**info})
  if record is not None:frames.extend(e.last_trace)
 result={'seed':seed,'task':e.kind,'backend':backend,'return':ret,'decisions':e.decisions,'end_reason':e.reason,'invalid_fraction':float(np.mean([x['invalid'] for x in rows])),'final':rows[-1]['metrics'],'best_J':min(x['metrics']['J'] for x in rows),'initial_J':initial_J,'contact_requests':sum(x['op']==1 for x in rows),'executed_contacts':sum(x['op']==1 and x['executed'] for x in rows)}
 if record is not None:
  path=Path(record);path.mkdir(parents=True,exist_ok=False);(path/'steps.json').write_text(json.dumps(rows,indent=2),encoding='utf8');(path/'manifest.json').write_text(json.dumps({'config':e.cfg.to_dict(),'backend':backend,'seed':seed,'result':result},indent=2),encoding='utf8');np.savez_compressed(path/'states.npz',initial_wall=initial,final_wall=e.material.wall)
  if frames:np.savez_compressed(path/'trajectory.npz',time_s=np.array([x['time_s'] for x in frames]),q=np.array([x['q'] for x in frames]),qvel=np.array([x['qvel'] for x in frames]),phase=np.array([x['phase'] for x in frames]),wall=np.array([x['wall'] for x in frames]),blade=np.array([x['blade'] for x in frames]))
 return result

def evaluate(model,reach_path,seeds,backend='nominal',teacher=None,kwargs=None):
 rows=[episode(model,s,reach_path,backend,teacher=teacher,kwargs=kwargs) for s in seeds]
 return {'episodes':rows,'mean_J':float(np.mean([x['final']['J'] for x in rows])),'mean_coverage':float(np.mean([x['final']['coverage'] for x in rows])),'mean_edge_coverage':float(np.mean([x['final']['edge_coverage'] for x in rows])),'mean_rmse_mm':float(np.mean([x['final']['rmse_mm'] for x in rows]))}
