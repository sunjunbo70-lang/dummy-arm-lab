"""Candidate numerical repair; historical mortar remains unchanged."""
import numpy as np
from ...wall_cycle.mortar import MortarSystem

class StableIndexMortar(MortarSystem):
    """Snap only floating-point roundoff at exact grid boundaries (5e-12 m)."""
    physics_version='v10r1.grid_boundary_roundoff.v1'
    def _indices(self,U,V):
        x=(U+self.cfg.width_m/2)/self.cfg.cell_m;y=V/self.cfg.cell_m
        x=np.where(np.abs(x-np.rint(x))<1e-9,np.rint(x),x)
        y=np.where(np.abs(y-np.rint(y))<1e-9,np.rint(y),y)
        iu=np.floor(x).astype(int);iv=np.floor(y).astype(int)
        good=(iu>=0)&(iu<self.wall.shape[1])&(iv>=0)&(iv<self.wall.shape[0])
        return iv,iu,good
